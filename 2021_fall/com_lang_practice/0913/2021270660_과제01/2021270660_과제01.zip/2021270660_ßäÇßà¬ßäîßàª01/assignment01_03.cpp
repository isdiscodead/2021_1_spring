#include <iostream>

int main() {
    std::cout << "이름: 이지원\n";
    std::cout << "학과: 컴퓨터융합소프트웨어학과\n";
    std::cout << "이메일: isdiscodead@korea.ac.kr\n";
    return 0;
}