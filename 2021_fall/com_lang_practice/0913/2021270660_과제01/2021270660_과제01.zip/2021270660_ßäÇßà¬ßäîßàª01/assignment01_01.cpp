#include <iostream>

int main() {
    int a = 25;
    int b = 35;
    int sum;

    sum = a + b;
    std::cout << sum;

    return 0;
}